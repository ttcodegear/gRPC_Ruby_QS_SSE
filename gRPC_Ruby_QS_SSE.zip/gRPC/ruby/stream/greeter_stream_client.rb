#!/usr/bin/env ruby

this_dir = File.expand_path(File.dirname(__FILE__))
stub_dir = File.join(this_dir, './')
$LOAD_PATH.unshift(stub_dir) unless $LOAD_PATH.include?(stub_dir)

require 'grpc'
require 'hellostreamingworld_services_pb'

class ReuestEnumerator
  def initialize()
    @requests = [
      Hellostreamingworld::HelloRequest.new(name: '山田太郎', num_greetings: "5"),
      Hellostreamingworld::HelloRequest.new(name: 'FooBar', num_greetings: "5")
    ]
  end

  def each_item
    return enum_for(:each_item) unless block_given?
    @requests.each do |request|
      yield request
    end
  end
end

stub = Hellostreamingworld::MultiGreeter::Stub.new('localhost:50052', :this_channel_is_insecure)
begin
  responses = stub.say_hello(ReuestEnumerator.new().each_item)
  responses.each do |response|
    puts "Greeter client received: #{response.message}"
  end
rescue Exception => ex
  puts ex
end
