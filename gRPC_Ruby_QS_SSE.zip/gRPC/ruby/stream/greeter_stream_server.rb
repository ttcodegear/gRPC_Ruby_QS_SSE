#!/usr/bin/env ruby

this_dir = File.expand_path(File.dirname(__FILE__))
stub_dir = File.join(this_dir, './')
$LOAD_PATH.unshift(stub_dir) unless $LOAD_PATH.include?(stub_dir)

require 'grpc'
require 'hellostreamingworld_services_pb'

class MultiGreeterServer < Hellostreamingworld::MultiGreeter::Service
  def say_hello(requests, call)
    ReplyEnumerator.new(requests, call).each_item
  end
end

class ReplyEnumerator
  def initialize(requests, call)
    @requests = requests
    @call = call
  end

  def each_item
    return enum_for(:each_item) unless block_given?
    @requests.each do |request|
      puts "Received request: #{request}"
      request.num_greetings.to_i.times do |i|
        reply = "こんにちは #{request.name}! #{i}"
        yield Hellostreamingworld::HelloReply.new(message: reply)
      end
    end
  end
end

server = GRPC::RpcServer.new
server.add_http2_port('0.0.0.0:50052', :this_port_is_insecure)
server.handle(MultiGreeterServer)
#server.run_till_terminated_or_interrupted(['SIGHUP', 'SIGINT', 'SIGQUIT'])
server.run_till_terminated_or_interrupted(%w[EXIT INT])
