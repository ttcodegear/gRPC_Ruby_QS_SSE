#!/usr/bin/env ruby

this_dir = File.expand_path(File.dirname(__FILE__))
stub_dir = File.join(this_dir, './')
$LOAD_PATH.unshift(stub_dir) unless $LOAD_PATH.include?(stub_dir)

require 'grpc'
require 'helloworld_services_pb'

channel_creds = GRPC::Core::ChannelCredentials.new(File.read("./server.crt"))
stub = Helloworld::Greeter::Stub.new('localhost:50051', channel_creds)
begin
  response = stub.say_hello(Helloworld::HelloRequest.new(name: '山田太郎'))
  puts "Greeter client received: #{response.message}"
rescue Exception => ex
  puts ex
end
